package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:22:45 PM
 */
public class GovernmentManager {

	public DataBaseHandler m_DataBaseHandler;

	public GovernmentManager(){

	}

	public void finalize() throws Throwable {

	}

	public Government HireEmployee(){
		return null;
	}

	public Government UpdateEmployee(){
		return null;
	}

	public void DeleteEmployee(String name,String vNumber){
            System.out.println("Suspended");

	}

	public void ViewEmployee(){
            
	}

	public void ManageDataBase(){

	}

}