package nat.project;

import java.util.Scanner;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:21:43 PM
 */
public class Government {

	private String userName;
	private String email;
	public GovernmentManager m_GovernmentManager;

	public Government(){
            this.email="No Information found";
            this.userName="No Information found";
	}

    public Government(String userName, String email, GovernmentManager m_GovernmentManager) {
        this.userName = userName;
        this.email = email;
        this.m_GovernmentManager = m_GovernmentManager;
    }

    public Government(String userName, String email) {
        this.userName = userName;
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public GovernmentManager getM_GovernmentManager() {
        return m_GovernmentManager;
    }

    public void setM_GovernmentManager(GovernmentManager m_GovernmentManager) {
        this.m_GovernmentManager = m_GovernmentManager;
    }
        
        
	public void finalize() throws Throwable {

	}

	public void blockCustomer(){

	}

	public void blockDriver(){

	}

	public void computeTax(){
            float tax;
            
	}

	public void showAnnouncement(){
                String policy;
                
                Scanner in=new Scanner(System.in);
                System.out.println("Enter the policy of the system");
                policy=in.nextLine();
	}

	public void showPolicy(){

	}

}