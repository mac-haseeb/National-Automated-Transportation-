package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:23:29 PM
 */
public class FacadaController {

	public CustomerManager m_CustomerManager;
	public DriverManager m_DriverManager;
	public GovernmentManager m_GovernmentManager;

	public FacadaController(){

	}

	public void finalize() throws Throwable {

	}

	public void Customerpatterns(){
            CustomerManager customer=new CustomerManager();
            customer.UpdateCustomer();
            BaseForm form=new BaseForm();
            form.setVisible(true);
	}

	public void DriversPatterns(){
            BaseForm form=new BaseForm();
            form.setVisible(true);
	}

	public void GovernmentPatterns(String name,String number){
            BaseForm form=new BaseForm();
            form.setVisible(true);
            
            
	}

}