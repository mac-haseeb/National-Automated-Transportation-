package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:21:08 PM
 */
public class Customers {

	private String name;
	private String email;
	public CustomerManager m_CustomerManager;

	public Customers(){
            this.email="No Information Found";
            this.name="No information Found";
	}

    public Customers(String name, String email, CustomerManager m_CustomerManager) {
        this.name = name;
        this.email = email;
        this.m_CustomerManager = m_CustomerManager;
    }

    public Customers(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CustomerManager getM_CustomerManager() {
        return m_CustomerManager;
    }

    public void setM_CustomerManager(CustomerManager m_CustomerManager) {
        this.m_CustomerManager = m_CustomerManager;
    }
        

	public void finalize() throws Throwable {

	}

	public Customers bookReservation(){
		return null;
	}

	public Customers updateReservation(){
		return null;
	}

	public void cancellReservation(){

	}

	public void viewReservation(){

	}

}