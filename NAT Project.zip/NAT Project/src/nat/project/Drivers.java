package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:21:27 PM
 */
public class Drivers {

	private String email;
	private String userName;
	private String cnic;
	private String vehicleName;
	private String vehicleNumber;
	private String vehicleColor;
	private String password;
	private String name;
	public DriverManager m_DriverManager;

	public Drivers(){
            this.cnic="No Information found";
            this.email="No Information found";
            this.name="No Information found";
            this.password="No Information found";
            this.userName="No Information found";
            this.vehicleColor="No Information found";
            this.vehicleNumber="No Information found";
	}

    public Drivers(String email, String userName, String cnic, String vehicleName, String vehicleNumber, String vehicleColor, String password, String name, DriverManager m_DriverManager) {
        this.email = email;
        this.userName = userName;
        this.cnic = cnic;
        this.vehicleName = vehicleName;
        this.vehicleNumber = vehicleNumber;
        this.vehicleColor = vehicleColor;
        this.password = password;
        this.name = name;
        this.m_DriverManager = m_DriverManager;
    }

    public Drivers(String email, String userName, String cnic, String vehicleName, String vehicleNumber, String vehicleColor, String password, String name) {
        this.email = email;
        this.userName = userName;
        this.cnic = cnic;
        this.vehicleName = vehicleName;
        this.vehicleNumber = vehicleNumber;
        this.vehicleColor = vehicleColor;
        this.password = password;
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getVehicleColor() {
        return vehicleColor;
    }

    public void setVehicleColor(String vehicleColor) {
        this.vehicleColor = vehicleColor;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DriverManager getM_DriverManager() {
        return m_DriverManager;
    }

    public void setM_DriverManager(DriverManager m_DriverManager) {
        this.m_DriverManager = m_DriverManager;
    }
        
        
	public void finalize() throws Throwable {

	}

	public int updateInformation(){
		return 0;
	}

}