package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:23:01 PM
 */
public class DataBaseHandler {

	public DataBaseHandler(){

	}

	public void finalize() throws Throwable {

	}

	public void Delete(){
               System.out.println("Deleted");
	}

	public void Update(){
            System.out.println("Updated");
	}

	public void View(){
            System.out.println("Viewed Successfully");
	}

	public void Crearte(){
            System.out.println("Created");
	}

}