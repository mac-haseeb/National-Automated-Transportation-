package nat.project;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:22:15 PM
 */
public class CustomerManager {

	public DataBaseHandler m_DataBaseHandler;

	public CustomerManager(){

	}

	public void finalize() throws Throwable {

	}

	public Customers CreateCustomer(){
		return null;
	}

	public Customers UpdateCustomer(){
		return null;
	}

	public void DeleteCustomer(){

	}

	public void ViewCustomer(){

	}

}