package nat.project;

import java.sql.Connection;



/**
 * @author Haseeb Ahmed
 * @version 1.0
 * @created 26-Jun-2021 3:22:30 PM
 */
public class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306storeserverTimezone, String root, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

	public DataBaseHandler m_DataBaseHandler;

	public DriverManager(){

	}

	public void finalize() throws Throwable {

	}

	public Drivers CreateDriver(){
		return null;
	}

	public Drivers UpdateDriver(){
		return null;
	}

	public void ViewDriver(){

	}

	public void DeleteDriver(){

	}

}